# coding: utf-8
import random
import time
import webbrowser
import sys
if sys.version_info < (3, 0):
    from Tkinter import * 
    import tkMessageBox
else:
    from tkinter import *
    import tkinter.messagebox as tkMessageBox

#import MySQLdb



class myTrail:

    '''
    initialize variables and UI
    '''
    def __init__(self):
        self.leftMoney = 1600
        self.food = 0
        self.clothes = 0
        self.book = 0
        self.supplies = 0
        self.points = 1000
        self.drink = 0
        self.refreshWindowType = 0
        #for score
        self.total = 0
        #for photo
        self.index = 0
        self.duckstoreIndex = 5
        self.randomIndex = 28

        #end game
        self.endfood = 0
        self.endclothes = 0


        #for test
        self.choice = " "
        self.passtest = 0

        
        #major start money
        self.undecided = 925
        self.CIS = 1085
        self.Business = 1250
        self.major = 0
        
        self.extra = 0
        self.grade = 70
        self.name = ""
        self.roommate = ""
        self.friend = 0

        self.term = "Fall term"
        self.week = 1

        self.first_run = 0
        self.step = 0
        self.question = ""
        self.answer1 = ""
        self.answer2 = ""
        self.answer3 = ""
        self.answer4 = ""
        self.answer5 = ""
        self.window_name = "My UO Trail"
        self.window = Tk()
        self.window.title(self.window_name)
        self.window.minsize(width=666, height=820)
        self.window.maxsize(width=666, height=820)

        


        #photo frame
        self.frame0 = Frame(self.window)
        Label(self.frame0, text = "  ").grid(row = 2, column = 1)
        aa = PhotoImage(file='giphy.gif', format = "gif -index " + str(self.index))
        image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
        self.frame0.image = aa
        self.frame0.pack()
        

        
        #question frame
        self.frame = Frame(self.window)
        self.frame.pack()
        self.question = "Welcome to my UO Trail"
        
        Button(self.frame, text = "Play", command = self.startGame).grid(row = 1, column = 1)
        Label(self.frame, text = "  ").grid(row = 2, column = 1)
        Button(self.frame, text = "Quit", command = self.close).grid(row = 3, column = 1)



    '''
    loads first window with UI including labels and images
    '''
    def startGame(self):
        self.setQuestion()

        
        #photo frame
        self.frame0.pack_forget()
        self.frame0 = Frame(self.window)
        aa = PhotoImage(file='giphy.gif', format = "gif -index " + str(self.index))
        image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
        self.frame0.image = aa
        self.frame0.pack()

        
        self.frame.pack_forget()
        self.frame = Frame(self.window)
        self.frame.pack()
        
        self.answer = StringVar()
        self.buy1 = StringVar()
        self.buy2 = StringVar()
        self.buy3 = StringVar()
        self.buy4 = StringVar()

        self.buy1.set("0")
        self.buy2.set("0")
        self.buy3.set("0")
        self.buy4.set("0")
            
        
        self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
        self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
        self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
        self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
        self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
        self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
        Entry(self.frame, textvariable = self.answer, width = 15).grid(row = 13, column = 1)
        
        self.button = Button(self.frame, text = "Submit", command = self.processSubmit).grid(row = 20, column = 1)
        #self.frame.bind("Return", self.button)


    '''
    refresh all variables on the window and display changes to user based on the values that set_question function gives it
    '''
    def refreshWindow(self, event = 0):
        #photo frame
        self.frame0.pack_forget()
        self.frame0 = Frame(self.window)
        aa = PhotoImage(file='giphy.gif', format = "gif -index " + str(self.index))
        image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
        self.frame0.image = aa
        self.frame0.pack()
            
        if self.first_run == 1:
            self.frame.pack_forget()
            self.frame = Frame(self.window)
            self.frame.pack()
        
        if event == 0:
            if self.step == 1:
                self.frame.pack_forget()
                self.frame = Frame(self.window)
                self.frame.pack()
            
            self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
            self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
            self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
            self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
            self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
            
            if self.step != 3:
                #for bind
                Entry(self.frame, textvariable = self.answer, width = 15).grid(row = 13, column = 1)
                Button(self.frame, text = "Submit", command = self.processSubmit).grid(row = 20, column = 1)
#                self.button.bind("Return", self.processSubmit())
#                self.button.grid(row = 20, column = 1)
#               self.ent = Entry(self.frame, textvariable = self.answer, width = 15).grid(row = 13, column = 1)
#                self.ent.bind("<Return>",self.processSubmit())
#                self.ent.pack(side=TOP)
#                btn = Button(self.frame,text="Submit", command = self.processSubmit())
#                btn.pack(side=LEFT)


            if self.step >= 3:
                #for bind button
                Button(self.frame, text = "Duck Store", command = self.duckStore).grid(row = 50, column = 1)
#                self.frame.storeButton = Button(self.frame, text = "Duck Store")
#                self.frame.storeButton.bind('<Return>', self.duckStore)
#                self.frame.storeButton.grid(row = 50, column = 1)
                
            if self.step > 4:
                
                Label(self.frame, text = "Current grade: " + str(self.grade)).grid(row = 25, column = 1, sticky = W)


                if self.leftMoney < 0:
                    Label(self.frame, text = "Money left: $0").grid(row = 26, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "Money left: $" + str(self.leftMoney)).grid(row = 26, column = 1, sticky = W)
                    
                if self.food < 0:
                    Label(self.frame, text = "No food left!!").grid(row = 27, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "Food left: "  + str(self.food) ).grid(row = 27, column = 1, sticky = W)

                if self.supplies < 0:
                    Label(self.frame, text = "No school supplies left!!").grid(row = 28, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "School supplies left: " + str(self.supplies)).grid(row = 28, column = 1, sticky = W)

                if self.clothes < 0:
                    Label(self.frame, text = "You have no clothes left - it's kind of cold running to class naked!").grid(row = 29, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "You have " + str(self.clothes) + " clothes.").grid(row = 29, column = 1, sticky = W)
                    
                Label(self.frame, text = "Books for this term: " + str(self.book)).grid(row = 30, column = 1, sticky = W)
                
                self.answer.set("")
        elif event == 3:
            #photo frame
            self.frame0.pack_forget()
            self.frame0 = Frame(self.window)
            bb = PhotoImage(file='random.gif', format = "gif -index " + str(self.randomIndex))
            image_label = Label(self.frame0, image = bb).grid(row = 4, column = 1, sticky = W)
            self.frame0.image = bb
            self.frame0.pack()
        
            self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
            self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
            self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
            self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
            self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
            Button(self.frame, text = "Keep Going", command = self.setQuestion).grid(row = 20, column = 1)

                
            
        elif event == 2:
            self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
            self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
            self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
            self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
            self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
            Button(self.frame, text = "Go Ducks", command = self.processSubmit).grid(row = 20, column = 1)

            if self.step >= 3:
                Button(self.frame, text = "Duck Store", command = self.duckStore).grid(row = 50, column = 1)
                
                
            if self.step > 4:
                
                Label(self.frame, text = "Current grade: " + str(self.grade)).grid(row = 25, column = 1, sticky = W)


                if self.leftMoney < 0:
                    Label(self.frame, text = "Money left: $0").grid(row = 26, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "Money left: $" + str(self.leftMoney)).grid(row = 26, column = 1, sticky = W)
                    
                if self.food < 0:
                    Label(self.frame, text = "No food left!!").grid(row = 27, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "Food left: " + str(self.food)).grid(row = 27, column = 1, sticky = W)

                if self.supplies < 0:
                    Label(self.frame, text = "No school supplies left!!").grid(row = 28, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "School supplies left: " + str(self.supplies)).grid(row = 28, column = 1, sticky = W)

                if self.clothes < 0:
                    Label(self.frame, text = "You have no clothes left - it's kind of cold running to class naked!").grid(row = 29, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "You have " + str(self.clothes) + " clothes.").grid(row = 29, column = 1, sticky = W)
                    
                Label(self.frame, text = "Books for this term: " + str(self.book)).grid(row = 30, column = 1, sticky = W)

        #finished first term           
        elif event == 5:
            self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
            self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
            self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
            self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
            self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
            self.reset_init()
            Label(self.frame, text = "See all high scores on our website ").grid(row = 18, column = 1, sticky = W)
            Button(self.frame, text = "Go", command = self.openWeb).grid(row = 18, column = 2)
            Button(self.frame, text = "Play Again", command = self.startGame).grid(row = 19, column = 1)
            Button(self.frame, text = "Exit", command = self.close).grid(row = 20, column = 1)
            
        elif event == 8:
            self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
            self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
            self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
            self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
            self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
            Button(self.frame, text = "Keep Going", command = self.setQuestion).grid(row = 20, column = 1)

            
        else:
            self.label1 = Label(self.frame, text = self.question).grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            self.label2 = Label(self.frame, text = self.answer1).grid(row = 3, column = 1, sticky = W)
            self.label3 = Label(self.frame, text = self.answer2).grid(row = 5, column = 1, sticky = W)
            self.label4 = Label(self.frame, text = self.answer3).grid(row = 7, column = 1, sticky = W)
            self.label5 = Label(self.frame, text = self.answer4).grid(row = 9, column = 1, sticky = W)
            self.label6 = Label(self.frame, text = self.answer5).grid(row = 11, column = 1, sticky = W)
            Button(self.frame, text = "Keep Going", command = self.processSubmit).grid(row = 20, column = 1)



            if self.step >= 3:
                Button(self.frame, text = "Duck Store", command = self.duckStore).grid(row = 50, column = 1)
                
            if self.step > 4:
                Label(self.frame, text = "Current grade: " + str(self.grade)).grid(row = 25, column = 1, sticky = W)


                if self.leftMoney < 0:
                    Label(self.frame, text = "Money left: $0").grid(row = 26, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "Money left: $" + str(self.leftMoney)).grid(row = 26, column = 1, sticky = W)
                    
                if self.food < 0:
                    Label(self.frame, text = "No food left!!").grid(row = 27, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "Food left: " + str(self.food)).grid(row = 27, column = 1, sticky = W)

                if self.supplies < 0:
                    Label(self.frame, text = "No school supplies left!!").grid(row = 28, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "School supplies left: " + str(self.supplies)).grid(row = 28, column = 1, sticky = W)

                if self.clothes < 0:
                    Label(self.frame, text = "You have no clothes left - it's kind of cold running to class naked!").grid(row = 29, column = 1, sticky = W)
                else:
                    Label(self.frame, text = "You have " + str(self.clothes) + " clothes.").grid(row = 29, column = 1, sticky = W)
                    
                Label(self.frame, text = "Books for this term: " + str(self.book)).grid(row = 30, column = 1, sticky = W)


        
        #self.window.bind('<Return>', self.processSubmit)
        self.first_run = 1
        self.answer.set("")


    '''
    open website in users browser
    '''
    def openWeb(self):
        webbrowser.open_new("http://ix.cs.uoregon.edu/~splunket/display_scores5.php")
            
    '''
    makes changes to all labels and give the new values to refresh_window function for every page
    '''
    def setQuestion(self):
        if self.step == 0:
            self.question = "Enter your character's name: "
            #set photo
            self.index = 1
            
        elif self.step == 1:
            self.question = "Please choose a major (please enter a, b, etc. to answer all questions)"
            self.answer1 = "A. Business"
            self.answer2 = "B. Computer and Information Science(CIS)"
            self.answer3 = "C. Undecided"
            self.answer4 = "D. Learn more about these choices"
            self.answer5 = " "
            #set photo
            self.index = 2
            
            self.refreshWindow()

            
        elif self.step == 2:
            self.question = "Please complete compatibility survey to best fit you with a new roommate. Are you more: "
            self.answer1 = "A. Messy/Loud/Willing to share your belongings"
            self.answer2 = "B. Clean/Quiet/Hate it when people touch your stuff"
            self.answer3 = ""
            self.answer4 = ""
            self.answer5 = ""
            #set photo
            self.index = 3
            
            self.refreshWindow()
        elif self.step == 3:
            if self.major == 1:
                mm = 1250
            elif self.major == 1.5:
                mm = 1085
            else:
                mm = 925

            self.question = "First you need to buy some supplies. You have $"+  str(mm) + " that your parents gave you for the first year. "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " Go to the Duck Store and get some things you would like to start with."
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 4
            
            self.refreshWindow()
            
            
        elif self.step == 4:
            self.refreshWindowType = 1
            self.question = "Congratulations you are officially a student at the University of Oregon! "
            self.answer1 = ""
            self.answer2 = ""
            self.answer3 = ""
            self.answer4 = ""
            self.answer5 = ""
            #set photo
            self.index = 6
            
            self.refreshWindow(2)
        elif self.step == 5:
            self.refreshWindowType = 1
            self.question = " It is the first week of the term "
            self.answer1 = "  You are just being a silly freshman, walking to class and meeting new people"
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 7
            
            self.refreshWindow(1)

        elif self.step == 6:
            self.refreshWindowType = 1
            self.question = " Week two "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 8
            
            self.refreshWindow(1)
            
        elif self.step == 7:
            self.refreshWindowType = 1
            self.question = " Week three "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 9
            
            self.refreshWindow(1)
            
        elif self.step == 8:
            self.refreshWindowType = 1
            self.question = " Week four "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 10
            
            self.refreshWindow(1)
            
            
            
        elif self.step == 9:
            self.refreshWindowType = 0
            self.question = " Week five: You’ve made it to the week of Midterms. You may choose: "
            self.answer1 = "A. To study for exams "
            self.answer2 = "B. To procrastinate and watch Netflix"
            self.answer3 = "C. To go to a party your roommate told you about"
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 11
            
            self.refreshWindow()

        elif self.step == 10:
            self.refreshWindowType = 1
            self.week = 6
            self.question = " Week six "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 12
            
            self.refreshWindow(1)
            
        elif self.step == 11:
            self.refreshWindowType = 1
            self.question = " Week seven "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 14
            
            self.refreshWindow(1)
        elif self.step == 12:
            self.refreshWindowType = 1
            self.question = " Week eight "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 13
            
            self.refreshWindow(1)
        elif self.step == 13:
            self.refreshWindowType = 1
            self.question = " Week nine "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            #set photo
            self.index = 15
            
            self.refreshWindow(1)
        elif self.step == 14:
            self.refreshWindowType = 0
            self.question = " It’s the weekend before finals week! You can choose to either: "
            self.answer1 = "A. Study hard for finals "
            self.answer2 = "B. Study for a couple hours, but then go to the REC because ball is LIFE! "
            self.answer3 = "C. Ditch studying altogether and go golfing with a couple of people who live next to you."
            self.answer4 = " "
            self.answer5 = " "


            
            #set photo
            self.index = 16
            
            self.refreshWindow()
            
        elif self.step == 90:
            self.refreshWindowType = 0

            if self.passtest == 1:
                
                self.question = " Congratulations, you passed the midterm "
                self.answer1 = " "
                self.answer2 = " "
                self.answer3 = " "
                self.answer4 = " "
                self.answer5 = " "
                
            else:
                self.question = " Sorry, you failed the midterm "
                self.answer1 = " "
                self.answer2 = " "
                self.answer3 = " "
                self.answer4 = " "
                self.answer5 = " "
                
            #set photo
            if self.choice == "a":
                self.index = 21
            elif self.choice == "b":
                self.index = 22
            else:
                self.index = 23

            self.step = 10
            self.refreshWindow(8)
            

        elif self.step == 95:
            if self.passtest == 1:
                
                self.question = " Congratulations, you passed the final test "
                self.answer1 = " "
                self.answer2 = " "
                self.answer3 = " "
                self.answer4 = " "
                self.answer5 = " "
                
            else:
                self.question = " Sorry, you failed the final test  "
                self.answer1 = " "
                self.answer2 = " "
                self.answer3 = " "
                self.answer4 = " "
                self.answer5 = " "
            #set photo
            if self.choice == "a":
                self.index = 24
            elif self.choice == "b":
                self.index = 25
            else:
                self.index = 26

            self.step = 100
            self.refreshWindow(8)
            
            
        elif self.step == 100:
            if self.book > 0:
                self.grade += 5
                self.grade = self.grade + (self.book - 1) * 2
            
            if self.leftMoney > 0:
                self.total += self.leftMoney
            if self.supplies > 0 :
                self.total += 2*self.supplies
            if self.clothes > 0:
                self.total += 50*self.clothes
            if self.food > 0:
                self.total += self.food * 3
            if self.friend > 0:
                self.total += self.friend * 20

            if self.grade >= 90:
                self.total += 500
            elif self.grade >= 80:
                self.total += 400
            elif self.grade >= 70:
                self.total += 250
            else:
                self.total += 0

            self.total = self.total * self.major

            if self.grade < 70:
                self.total = 0
            
                self.question = " Fall term finished "
                self.answer1 = " "
                self.answer2 = " Your grade = " + str(self.grade)
                self.answer3 = " Since you failed this term, your points are " + str(self.total)
                self.answer4 = " "
                self.answer5 = " "
            else:
                self.question = " Fall term finished "
                self.answer1 = " "
                self.answer2 = " Your grade = " + str(self.grade)
                self.answer3 = " Congratulations, you passed this term and your points are " + str(self.total)
                self.answer4 = " "
                self.answer5 = " Your scores has been pushed to our database"
                
                self.push_to_database(self.total)

            #photo
            if self.grade < 60:
                self.index = 17
            elif self.grade < 80:
                self.index = 19
            else:
                self.index = 18

            
            self.refreshWindow(5)



    '''
    pushes the score to database if the user passes the term
    '''
    def push_to_database(self,total):
        myDB = MySQLdb.connect(host="ix.cs.uoregon.edu",port=3965,user="splunkett",passwd="RosePlunkett2014",db="high_score")
        cHandler = myDB.cursor()
        tup = (self.name, total)
        cHandler.execute("INSERT INTO high_scores VALUES " + str(tup))
        cHandler.close()
        myDB.commit()
        myDB.close()


    '''
    process all the results based on the users choice
    have 40 percent of chance that calls the random function so the random event happens
    '''
    def processSubmit(self, event = None):
        if self.endfood >= 2:
            self.end_game(1)
            return
        if self.endclothes >= 3:
            self.end_game(2)
            return


        if self.step >= 4 and self.step != 14:
            if self.step != 9:
                
                if self.food <= 0:
                    self.endfood += 1
                    self.food = 0
                else:
                    self.food = self.food - 20
                    if self.food <= 0:
                        self.food = 0

                if self.clothes <= 0:
                    self.clothes = 0
                    self.endclothes += 1


                if self.supplies <= 0:
                    self.grade = self.grade - 5
                    self.supplies = 0
                else:
                    self.supplies = self.supplies - 3
                    if self.supplies <= 0:
                        self.supplies = 0


        if self.step == 0:
            if self.answer.get() == "":
                tkMessageBox.showinfo("Error " + self.name, "Please enter a name to continue.")
                return
            elif self.answer.get().isspace() == True:
                tkMessageBox.showinfo("Error " + self.name, "Please enter a name to continue.")
                return
            self.name = self.answer.get()
            self.step += 1
            self.setQuestion()
            
        elif self.step == 1:
            if self.answer.get() == 'a' or self.answer.get() == 'A':
                self.leftMoney = self.Business
                self.major = 1
                self.step += 1
                self.setQuestion()
            elif self.answer.get() == 'b' or self.answer.get() == 'B':
                self.leftMoney = self.CIS
                self.major = 1.5
                self.step += 1
                self.setQuestion()
            elif self.answer.get() == 'c' or self.answer.get() == 'C':
                self.leftMoney = self.undecided
                self.major = 2
                self.step += 1
                self.setQuestion()
            elif self.answer.get() == 'd' or self.answer.get() == 'D':
                self.explain()
            
            else:
                tkMessageBox.showinfo("Error ", "Please enter a valid choice (a-d).")

                
        elif self.step == 2:
            if self.answer.get() == 'a' or self.answer.get() == 'A':
                self.roommate = 'a'
                self.step += 1
                self.setQuestion()
            elif self.answer.get() == 'b' or self.answer.get() == 'B':
                self.roomate = 'b'
                self.step += 1
                self.setQuestion()
            else:
                tkMessageBox.showinfo("Error ", "Please enter a valid choice.")

                
        elif self.step == 3:
                self.step += 1
                self.setQuestion()
                
                
        elif self.step == 4:
            self.step = 5
            self.week = 1


            random_num = random.randint(1,10)

            #change to 5
            if random_num > 2:
                self.setQuestion()
            else:
                self.extra_event(1)
            
        elif self.step == 5:
            self.week = 2
            self.step = 6

            #change to 40
            extra = random.uniform(1,100)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)

                
        elif self.step == 6:
            self.week = 3
            self.step = 7
            
            #change to 40
            extra = random.uniform(1,100)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)

                
        elif self.step == 7:
            self.week = 4
            self.step = 8
            
            #change to 40
            extra = random.uniform(1,100)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)

                
        elif self.step == 8:
            self.week = 5
            self.step = 9
            
            #change to 40
            extra = random.uniform(1,40)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)  
            
        elif self.step == 9:
            self.refreshWindowType = 1
            if self.answer.get() == 'a' or self.answer.get() == 'A':
                if self.food <= 0:
                    self.endfood += 1
                    self.food = 0
                else:
                    self.food = self.food - 20
                    if self.food <= 0:
                        self.food = 0

                if self.clothes <= 0:
                    self.clothes = 0
                    self.endclothes += 1


                if self.supplies <= 0:
                    self.grade = self.grade - 5
                    self.supplies = 0
                else:
                    self.supplies = self.supplies - 3
                    if self.supplies <= 0:
                        self.supplies = 0



                    
                self.week = 6
                chance = random.randint(1,10)
                if chance <= 9:
                    self.grade += 5
                    self.passtest = 1
                else:
                    self.grade -= 5
                    self.passtest = 0

                self.choice = "a"
                self.step = 90
                self.setQuestion()
                
            elif self.answer.get() == 'b' or self.answer.get() == 'B':

                if self.food <= 0:
                    self.endfood += 1
                    self.food = 0
                else:
                    self.food = self.food - 20
                    if self.food <= 0:
                        self.food = 0

                if self.clothes <= 0:
                    self.clothes = 0
                    self.endclothes += 1


                if self.supplies <= 0:
                    self.grade = self.grade - 5
                    self.supplies = 0
                else:
                    self.supplies = self.supplies - 3
                    if self.supplies <= 0:
                        self.supplies = 0



                        
                self.week = 6
                self.friend += 1
                chance = random.randint(1,10)
                if chance <= 7:
                    self.passtest = 1
                    self.grade += 5
                else:
                    self.passtest = 0
                    self.grade -= 5

                self.choice = "b"
                self.step = 90
                self.setQuestion()
                
            elif self.answer.get() == 'c' or self.answer.get() == 'C':
                if self.food <= 0:
                    self.endfood += 1
                    self.food = 0
                else:
                    self.food = self.food - 20
                    if self.food <= 0:
                        self.food = 0

                if self.clothes <= 0:
                    self.clothes = 0
                    self.endclothes += 1


                if self.supplies <= 0:
                    self.grade = self.grade - 5
                    self.supplies = 0
                else:
                    self.supplies = self.supplies - 3
                    if self.supplies <= 0:
                        self.supplies = 0


                        
                self.friend += 2
                chance = random.randint(1,10)
                if chance <= 5:
                    self.passtest = 1
                    self.grade += 5
                else:
                    self.passtest = 0
                    self.grade -= 5

                self.choice = "c"
                #change to 5 instead of 10 when finish
                extra = random.randint(1,10)
                if extra > 5:
                    self.week = 6

                    self.step = 90
                    self.setQuestion()
                else:
                    self.step = 90
                    self.extra_event(2)

            else:
                tkMessageBox.showinfo("Error ", "Please enter a valid choice.")



        elif self.step == 10:
            self.week = 7
            self.step = 11

            #change to 40
            extra = random.uniform(1,100)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)
        elif self.step == 11:
            self.week = 8
            self.step = 12
            
            #change to 40
            extra = random.uniform(1,100)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)

        elif self.step == 12:
            self.week = 9
            self.step = 13

            #change to 40
            extra = random.uniform(1,100)
            if extra > 40:
                self.setQuestion()
            else:
                self.random_event(extra)

        elif self.step == 13:
            self.week = 10
            self.step = 14
            self.setQuestion()

            
        elif self.step == 14:
            
            
            if self.answer.get() == 'a' or self.answer.get() == 'A':
                if self.supplies < 15:
                    tkMessageBox.showinfo("Error ", "This option needs 15 supplies, you don't have enough supplies to study hard for finals.")
                else:
                    self.step = 95
                    self.supplies = self.supplies - 15
                    final_chance = random.uniform(1,200)
                    self.choice = "a"
                    if final_chance <= 170:
                        self.grade += 10
                        self.passtest = 1
                    else:
                        self.passtest = 0
                        self.grade = self.grade - 10
                    self.setQuestion()
                    
            elif self.answer.get() == 'b' or self.answer.get() == 'B':
                if self.supplies < 5:
                    tkMessageBox.showinfo("Error ", "This option requires 5 supplies, you don't have enough supplies to study for finals.")
                else:
                    self.step = 95
                    self.choice = "b"
                    self.supplies = self.supplies - 5
                    self.friend += 1
                    final_chance = random.uniform(1,200)
                    if final_chance <= 140:
                        self.passtest = 1
                        self.grade += 10
                    else:
                        self.passtest = 0
                        self.grade = self.grade - 10
                    self.setQuestion()

                    
            elif self.answer.get() == 'c' or self.answer.get() == 'C':
                self.friend += 2
                self.step = 95
                self.choice = "c"
                final_chance = random.uniform(1,200)
                if final_chance <= 100:
                    self.passtest = 1
                    self.grade += 10
                else:
                    self.passtest = 0
                    self.grade = self.grade - 10
                self.setQuestion()
                    
            else:
                tkMessageBox.showinfo("Error ", "Please enter a valid choice.")
            

    '''
    the two extra event initiated at specific times
    '''
    def extra_event(self, event_num):
        if event_num == 1:
            self.question = "It’s your first day of class. On your way to class a senior pushes you to the ground, saying"
            self.answer1 = "'Get out of the way freshman' "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = "-You lost 1 set of clothes "
            self.answer5 = " "
            self.clothes = self.clothes - 1
            #photo
            self.randomIndex = 23
            self.refreshWindow(3)
        elif event_num == 2:
            self.question = " Congratulations! "
            self.answer1 = " You went to the party and gained a hot date "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " "
            self.answer5 = " "
            self.friend += 2
            #photo
            self.randomIndex = 17
            self.refreshWindow(3)



    '''
    show duckstore page when user clicked the duck store button
    '''
    def duckStore(self):
        
        #photo frame
        self.frame0.pack_forget()
        self.frame0 = Frame(self.window)
        aa = PhotoImage(file='giphy.gif', format = "gif -index " + str(self.duckstoreIndex))
        image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
        self.frame0.image = aa
        self.frame0.pack()
        

        
        self.frame.pack_forget()
        self.frame = Frame(self.window)
        self.frame.pack()


        self.label1 = Label(self.frame, text = "Welcome to the Duck Store").grid(row = 1, column = 1)
        Label(self.frame, text = "  ").grid(row = 2, column = 1)
        label2 = Label(self.frame, text = "Books            $100 each").grid(row = 3, column = 1, sticky = W)
        label3 = Label(self.frame, text = "School Supplies   $2   each").grid(row = 5, column = 1, sticky = W)
        label4 = Label(self.frame, text = "Set of Clothes   $75  each").grid(row = 7, column = 1, sticky = W)
        label5 = Label(self.frame, text = "Food             $3 per meal").grid(row = 9, column = 1, sticky = W)
        
        Entry(self.frame, textvariable = self.buy1, width = 15).grid(row = 3, column = 2)
        Entry(self.frame, textvariable = self.buy2, width = 15).grid(row = 5, column = 2)
        Entry(self.frame, textvariable = self.buy3, width = 15).grid(row = 7, column = 2)
        Entry(self.frame, textvariable = self.buy4, width = 15).grid(row = 9, column = 2)

        Label(self.frame, text = "  ").grid(row = 10, column = 1)
        Label(self.frame, text = "Select the number of items you would like to buy").grid(row = 11, column = 1)
        Label(self.frame, text = "  ").grid(row = 12, column = 1)
        Label(self.frame, text = " Your money left: $"+ str(self.leftMoney)).grid(row = 12, column = 1)
        Label(self.frame, text = "  ").grid(row = 14, column = 1)
        
        
        Button(self.frame, text = "Purchase", command = self.processBuy).grid(row = 20, column = 1)
        Label(self.frame, text = "  ").grid(row = 21, column = 1)
        Label(self.frame, text = "  ").grid(row = 22, column = 1)
        Label(self.frame, text = " Things you have left ").grid(row = 23, column = 1,sticky = W)
        Label(self.frame, text = " Food: " + str(self.food)).grid(row = 24, column = 1,sticky = W)
        Label(self.frame, text = " School supplies: " + str(self.supplies)).grid(row = 25, column = 1,sticky = W)
        Label(self.frame, text = " Clothes: "+ str(self.clothes)).grid(row = 26, column = 1,sticky = W)
        Label(self.frame, text = " Book: " + str(self.book)).grid(row = 27, column = 1,sticky = W)



    '''
    make changes to food, supplies, clothes, book and money after user makes purchase.
    '''
    def processBuy(self):
        try:
            a = int(self.buy1.get())
            b = int(self.buy2.get())
            c = int(self.buy3.get())
            d = int(self.buy4.get())
        except ValueError:
            tkMessageBox.showinfo("Error ", "Please enter a number for all entries.")
            return

        
        total = a*100 + b*2 + c*75 + d*3
        if total > self.leftMoney:
            tkMessageBox.showinfo("Oops ", "You don't have enought money to buy all of the selected items.")
        else:
            self.leftMoney = self.leftMoney - total
            if self.food < 0 and d > 0:
                self.food = 0
                self.points = self.points - (self.endfood * 3)
                self.endfood = 0
            self.food += d

            if self.clothes < 0 and c > 0:
                self.clothes = 0
                self.points = self.points - (self.endclothes * 50)
                self.endclothes = 0
            self.clothes += c
            
            self.book += a
            if self.supplies < 0 and b > 0:
                self.supplies = 0
            self.supplies += b

            self.buy1.set("0")
            self.buy2.set("0")
            self.buy3.set("0")
            self.buy4.set("0")
            if self.step == 3:
                self.step += 1
                self.setQuestion()
            else:
                self.refreshWindow(self.refreshWindowType)


    '''
    explaining the difference between majors when user selects that choice
    '''
    def explain(self):
        if self.step == 1:
            self.question = " Deciding your major "
            self.answer1 = " Business majors receive $1,250 at the beginning of each term. "
            self.answer2 = " Computer science majors receive $1,085 but get a point bonus at the end of the game. "
            self.answer3 = " Undecided majors receive $925 per term but get an even bigger multiplier at the end. "
            self.answer4 = " "
            self.answer5 = " "
            self.refreshWindow(3)
        

    '''
    all random events could happen every and have their own probability of occuring
    '''
    def random_event(self, event_number):
        #event that lose supplies
        if event_number <= 4:
            self.question = " You got sick "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " lose 5 supplies"
            self.answer5 = " "
            if self.supplies <= 5:
                self.supplies = 0
            else:
                self.supplies = self.supplies - 5

            #photo
            self.randomIndex = 26
            self.refreshWindow(3)
            
        elif event_number <= 7:
            self.question = " Left your notebook in the classroom "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 10 supplies "
            self.answer5 = " "
            if self.supplies <= 10:
                self.supplies = 0
            else:
                self.supplies = self.supplies - 10

            #photo
            self.randomIndex = 20
            self.refreshWindow(3)

            
        elif event_number <= 8:
            self.question = " Your bike gets stolen "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 7 supplies "
            self.answer5 = " "
            if self.supplies <= 7:
                self.supplies = 0
            else:
                self.supplies = self.supplies - 7

            #photo
            self.randomIndex = 0
            self.refreshWindow(3)
            
        elif event_number <= 11:
            self.question = " You overslept and missed a pop quiz "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 15 supplies "
            self.answer5 = " "
            if self.supplies <= 15:
                self.supplies = 0
            else:
                self.supplies = self.supplies - 15

            #photo
            self.randomIndex = 7
            self.refreshWindow(3)
            
        elif event_number <= 13:
            self.question = " Dropped your phone in a puddle "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 5 supplies "
            self.answer5 = " "
            if self.supplies <= 5:
                self.supplies = 0
            else:
                self.supplies = self.supplies - 5

            #photo
            self.randomIndex = 5
            self.refreshWindow(3)
            
        elif event_number <= 17:
            self.question = " You fell asleep in class "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 3 supplies "
            self.answer5 = " "
            if self.supplies <= 3:
                self.supplies = 0
            else:
                self.supplies = self.supplies - 3

            #photo
            self.randomIndex = 6
            self.refreshWindow(3)
           
        #event that gain supplies
        elif event_number <= 18.5:
            self.question = " A study group has asked you to join them "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Gain 10 supplies "
            self.answer5 = " "
            self.supplies += 10

            #photo
            self.randomIndex = 27
            self.refreshWindow(3)
            
        elif event_number <= 20:
            self.question = " A friend has already taken the class you are in and gave you their notes "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Gain 10 supplies "
            self.answer5 = " "
            self.supplies += 10

            #photo
            self.randomIndex = 11
            self.refreshWindow(3)
            
        #event that lose money
        elif event_number <= 21:
            self.question = " You broke your arm in PE class "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " lost $100 emergency room fee"
            self.answer5 = " "
            if self.leftMoney <= 100:
                self.leftMoney = 0
            else:
                self.leftMoney = self.leftMoney - 100

            #photo
            self.randomIndex = 1
            self.refreshWindow(3)
            
        elif event_number <= 21.3:
            self.question = " You forgot an online signature on your FAFSA form "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose $300 money "
            self.answer5 = " "
            if self.leftMoney <= 300:
                self.leftMoney = 0
            else:
                self.leftMoney = self.leftMoney - 300

            #photo
            self.randomIndex = 9
            self.refreshWindow(3)
            
        elif event_number <= 23.3:
            self.question = " Got food poisoning from Carson "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose $40 for Health Center fees "
            self.answer5 = " "
            if self.leftMoney <= 40:
                self.leftMoney = 0
            else:
                self.leftMoney = self.leftMoney - 40

            #photo
            self.randomIndex = 8
            self.refreshWindow(3)
            
        elif event_number <= 23.8:
            self.question = " You lost the key to your dorm room "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose $80 for the cost of replacing your key "
            self.answer5 = " "
            if self.leftMoney <= 80:
                self.leftMoney = 0
            else:
                self.leftMoney = self.leftMoney - 80

            #photo
            self.randomIndex = 21
            self.refreshWindow(3)
        
        #event that gain money
        elif event_number <= 26.8:
            self.question = " You found a $20 bill on the ground "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Gain $20 "
            self.answer5 = " "
            self.leftMoney += 20

            #photo
            self.randomIndex = 10
            self.refreshWindow(3)
            
        elif event_number <= 28.8:
            self.question = " Your grandma sent you money for your birthday "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Gain $47 "
            self.answer5 = " "
            self.leftMoney += 47

            #photo
            self.randomIndex = 18
            self.refreshWindow(3)

        #event that lose food
        elif event_number <= 31.8:
            self.question = " Dropped breakfast on way to class "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " lose 10 food "
            self.answer5 = " "
            if self.food <= 10:
                self.food = 0
            else:
                self.food = self.food - 10

            #photo
            self.randomIndex = 4
            self.refreshWindow(3)
            
        elif event_number <= 33.8:
            self.question = " Your sibling comes to visit "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 15 food "
            self.answer5 = " "
            if self.food <= 15:
                self.food = 0
            else:
                self.food = self.food - 15

            #photo
            self.randomIndex = 25
            self.refreshWindow(3)

        #event that gain food
        elif event_number <= 35.8:
            self.question = " Your roommate buys a Costco pack of ramen "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Gain one week's worth of food "
            self.answer5 = " "
            self.food += 20

            #photo
            self.randomIndex = 24
            self.refreshWindow(3)

        #event that lose clothes
        elif event_number <= 36.3:
            self.question = " Your clothes are stolen from the laundry room "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Lose 2 outfits "
            self.answer5 = " "
            if self.clothes <= 2:
                self.clothes = 0
            else:
                self.clothes = self.clothes - 2

            #photo
            self.randomIndex = 2
            self.refreshWindow(3)
        #other event
        elif event_number <= 39.3:
            self.question = " You got hit on by DERK on the way to class"
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " "
            self.answer4 = " Nothing happened, you were just disgusted by the interaction! "
            self.answer5 = " "

            #photo
            self.randomIndex = 12
            self.refreshWindow(3)
            
        elif event_number <= 39.5:
            self.question = "OH NO!! You have died of dysentery. "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " Game Over "
            self.answer4 = " "
            self.answer5 = " "
            self.end_game(3)
            
        elif event_number <= 40:
            self.question = " Got caught drinking in the residence halls by the RA "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " If you got caught another time, you lose!! "
            self.answer4 = " "
            self.answer5 = " "
            self.drink = self.drink + 1
            if self.drink == 2:
                self.end_game(4)
            else:
                #photo
                self.randomIndex = 13
                self.refreshWindow(3)
            
        else:
            self.question = " Win $100 lottery ticket "
            self.answer1 = " "
            self.answer2 = " "
            self.answer3 = " Gain $100 "
            self.answer4 = " "
            self.answer5 = " "
            self.refreshWindow(3)


    '''
    when the player loses the game, the end of window display
    '''
    def end_game(self, message):
        
        if message == 1:
            #photo frame
            self.frame0.pack_forget()
            self.frame0 = Frame(self.window)
            aa = PhotoImage(file='random.gif', format = "gif -index 15")
            image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
            self.frame0.image = aa
            self.frame0.pack()
            
            self.frame.pack_forget()
            self.frame = Frame(self.window)
            self.frame.pack()
            self.label1 = Label(self.frame, text = "Game Over").grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            Label(self.frame, text = "You have been out of food for two weeks, you are too weak to continue").grid(row = 3, column = 1, sticky = W)
            Label(self.frame, text = "  ").grid(row = 4, column = 1)
            Label(self.frame, text = "Time to go home to Mom and Dad!!").grid(row = 5, column = 1, sticky = W)
            Button(self.frame, text = "Play Again", command = self.startGame).grid(row = 19, column = 1)
            self.reset_init()
            Button(self.frame, text = "Exit", command = self.close).grid(row = 20, column = 1)
            
            
        elif message == 2:
            #photo frame
            self.frame0.pack_forget()
            self.frame0 = Frame(self.window)
            aa = PhotoImage(file='random.gif', format = "gif -index 14")
            image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
            self.frame0.image = aa
            self.frame0.pack()
            
            self.frame.pack_forget()
            self.frame = Frame(self.window)
            self.frame.pack()
            self.label1 = Label(self.frame, text = "Game Over").grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
        
            Label(self.frame, text = " You went to class naked for many weeks, you parents are embarrassed").grid(row = 3, column = 1, sticky = W)
            Label(self.frame, text = "  ").grid(row = 4, column = 1)
            Label(self.frame, text = "Time to go home to Mom and Dad!!").grid(row = 5, column = 1, sticky = W)
            Button(self.frame, text = "Play Again", command = self.startGame).grid(row = 19, column = 1)
            self.reset_init()
            Button(self.frame, text = "Exit", command = self.close).grid(row = 20, column = 1)

        elif message == 3:
            #photo frame
            self.frame0.pack_forget()
            self.frame0 = Frame(self.window)
            aa = PhotoImage(file='random.gif', format = "gif -index 3")
            image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
            self.frame0.image = aa
            self.frame0.pack()
            
            self.frame.pack_forget()
            self.frame = Frame(self.window)
            self.frame.pack()
            self.label1 = Label(self.frame, text = "Game Over").grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            
            Label(self.frame, text = " OH NO!! You got Dysentery ").grid(row = 3, column = 1, sticky = W)
            Label(self.frame, text = "  ").grid(row = 4, column = 1)
            Label(self.frame, text = "Game Over!!!!!!!").grid(row = 5, column = 1, sticky = W)
            Button(self.frame, text = "Play Again", command = self.startGame).grid(row = 19, column = 1)
            self.reset_init()
            Button(self.frame, text = "Exit", command = self.close).grid(row = 20, column = 1)
        else:
            #photo frame
            self.frame0.pack_forget()
            self.frame0 = Frame(self.window)
            aa = PhotoImage(file='random.gif', format = "gif -index 16")
            image_label = Label(self.frame0, image = aa).grid(row = 4, column = 1, sticky = W)
            self.frame0.image = aa
            self.frame0.pack()

            
            self.frame.pack_forget()
            self.frame = Frame(self.window)
            self.frame.pack()
            self.label1 = Label(self.frame, text = "Game Over").grid(row = 1, column = 1)
            Label(self.frame, text = "  ").grid(row = 2, column = 1)
            
            Label(self.frame, text = " OH!! You got caught twice drinking in the residence halls by the RA ").grid(row = 3, column = 1, sticky = W)
            Label(self.frame, text = "  ").grid(row = 4, column = 1)
            Label(self.frame, text = "Game Over!!!!!!!").grid(row = 5, column = 1, sticky = W)

            self.reset_init()
            Button(self.frame, text = "Play Again", command = self.startGame).grid(row = 19, column = 1)
            Button(self.frame, text = "Exit", command = self.close).grid(row = 20, column = 1)

    '''
    called when user selects exit button
    '''
    def close(self):
        self.window.destroy()
        
        

    '''
    reset all values befor starting new game
    '''
    def reset_init(self):
        self.undecided = 925
        self.CIS = 1085
        self.Business = 1250
        self.major = 0
        
        self.extra = 0
        self.grade = 70
        self.name = ""
        self.roommate = ""
        self.friend = 0

        self.term = "Fall term"
        self.week = 1

        self.first_run = 0
        self.step = 0
        self.question = ""
        self.answer1 = ""
        self.answer2 = ""
        self.answer3 = ""
        self.answer4 = ""
        self.answer5 = ""
        self.leftMoney = 1600
        self.food = 0
        self.clothes = 0
        self.book = 0
        self.supplies = 0
        self.points = 1000
        self.drink = 0
        self.refreshWindowType = 0
        #for score
        self.total = 0
        #for photo
        self.index = 0
        self.duckstoreIndex = 5
        self.randomIndex = 28

        #end game
        self.endfood = 0
        self.endclothes = 0


        #for test
        self.choice = " "
        self.passtest = 0

a = myTrail()
a.window.mainloop()

